import React from "react"
import { Shop } from "./components/Shop"

function App() {
	return (
		<div className='App'>
			<h1>Магазин Fortnite</h1>
			<Shop />
		</div>
	)
}

export default App
