import React from "react"

function Preloader() {
	return <div className='preloader'>Загрузка...</div>
}

export { Preloader }
