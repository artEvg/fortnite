import React from "react"
import "./GoodsItem.css" // Import the CSS file

function GoodsItem({ id, name, type, description, price, image }) {
	const handleBuyClick = () => {
		alert(`Вы купили ${name} за ${price.finalPrice} РУБ.`)
	}

	return (
		<div className='card'>
			<div className='card-image'>
				<img
					src={image}
					alt={name}
				/>
			</div>
			<div className='card-content'>
				<span className='card-title'>{name}</span>
				<p>
					<strong>Тип:</strong> {type} {/* Displaying item type */}
				</p>
				<p>
					<strong>Описание:</strong> {description || "Нет описания"}{" "}
					{/* Displaying item description */}
				</p>
				<div className='card-action'>
					<button
						className='btn'
						onClick={handleBuyClick}>
						КУПИТЬ
					</button>
					<span>{price.finalPrice} РУБ.</span>
				</div>
			</div>
		</div>
	)
}

export { GoodsItem }
