const API_KEY = "c2ad5483-593f794b-c5f8e037-81da5a59"
const API_URL = "https://fortniteapi.io/v2/shop?lang=ru"

export { API_KEY, API_URL }
